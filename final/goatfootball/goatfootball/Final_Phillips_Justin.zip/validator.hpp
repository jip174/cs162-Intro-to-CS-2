/*********************************************************************
** Program name :  Final Project
** Author : Justin Phillips
** Date : 3 / 04 / 2018
** Description : Goat Football
*********************************************************************/

#ifndef VALIDATOR_H
#define VALIDATOR_H
#include <string>
#include <iostream>

int numValidator( int min,int max);
int getInt();

#endif
