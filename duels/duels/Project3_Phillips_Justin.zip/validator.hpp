/*********************************************************************
** Program name : Project 3
** Author : Justin Phillips
** Date : 2 / 05 / 2018
** Description : Fantasy Combat Game
*********************************************************************/

#ifndef VALIDATOR_H
#define VALIDATOR_H
#include <string>
#include <iostream>

int numValidator( int min,int max);
int getInt();

#endif
